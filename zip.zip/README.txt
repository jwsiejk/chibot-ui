Flow Export
==========

Session ID: 02113d82c6ce418684b1f55fc827a35f
Created: 2025-10-27T23:04:04.897000Z

This archive contains privacy-safe flow artifacts:
- manifest.json: session metadata, integrity digests, and truncation notes.
- events.redacted.ndjson: chronological event stream with telemetry redaction re-applied.
- flow_timeline.ndjson: key timeline markers (turns, TTS, mic gate, policy, WS state).
- nlu.ndjson: captured NLU evaluations.
- nlg.ndjson: assistant planning and wording events.

Files are ordered lexicographically inside the archive. For documentation, see /docs.
