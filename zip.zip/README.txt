Flow Export
==========

Session ID: b5ce72122da545b6bb5f59f0fc0f7cb5
Created: 2025-11-22T16:42:53.433000Z

This archive contains privacy-safe flow artifacts:
- manifest.json: session metadata, integrity digests, and truncation notes.
- events.redacted.ndjson: chronological event stream with telemetry redaction re-applied.
- flow_timeline.ndjson: key timeline markers (turns, TTS, mic gate, policy, WS state).
- nlu.ndjson: captured NLU evaluations.
- nlg.ndjson: assistant planning and wording events.

Files are ordered lexicographically inside the archive. For documentation, see /docs.
