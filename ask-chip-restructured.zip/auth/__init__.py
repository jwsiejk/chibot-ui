# Initializes auth package
