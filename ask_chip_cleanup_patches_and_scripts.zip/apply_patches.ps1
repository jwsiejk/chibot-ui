# Apply small patches in order (Windows PowerShell)
$ErrorActionPreference = "Stop"
git apply "patch_tts_bridge_aliases.patch"
git apply "patch_render_aliases.patch"
git apply "patch_conversation_remove_calllog_import.patch"
Write-Host "Patches applied. Next: run cleanup_remove_files.ps1 to delete legacy files."
