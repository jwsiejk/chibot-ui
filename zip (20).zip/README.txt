Flow Export
==========

Session ID: 9579a9fcc9634d95a35402960e33f105
Created: 2025-10-28T02:22:45.677000Z

This archive contains privacy-safe flow artifacts:
- manifest.json: session metadata, integrity digests, and truncation notes.
- events.redacted.ndjson: chronological event stream with telemetry redaction re-applied.
- flow_timeline.ndjson: key timeline markers (turns, TTS, mic gate, policy, WS state).
- nlu.ndjson: captured NLU evaluations.
- nlg.ndjson: assistant planning and wording events.

Files are ordered lexicographically inside the archive. For documentation, see /docs.
